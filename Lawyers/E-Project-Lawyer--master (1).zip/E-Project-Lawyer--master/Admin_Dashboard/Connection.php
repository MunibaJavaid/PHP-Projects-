    <?php
      $con =  mysqli_connect('localhost','root','','lawyer');

      if(!$con){
          echo "Connection Failed";
      }
    //   else{
    //       echo "connection not succeed";
    //   }
    ?>
