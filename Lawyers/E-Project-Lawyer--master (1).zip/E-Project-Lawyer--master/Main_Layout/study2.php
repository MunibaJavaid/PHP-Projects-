<?php include 'header.php';?>

<style>
   .link{
      color:blue;
   }
   .link:hover{
      color: rgb(141, 108, 52);
   }
</style>

<div width = "100%" height = "400px">
   <img src="assets/images/bg/criminal.png" alt="" width = "100%" height = "400px">
</div>
<div text align ="center" bold padding="10px"><br><br>
               <h1>Description</h1>
            </div>
<div class="row justify-content-center mt-5 g-4 container-fluid">
            <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInDown" data-wow-duration="1.5s" data-wow-delay="0.2s">
               <div class="casestudy-single" text align= "center">
                  <img src="assets/images/bg/criminal1.png" class="casestudy1" alt="image">
                
                  <div class="text">
                     
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInDown" data-wow-duration="1.5s" data-wow-delay="0.4s" fontsize = "50px">
             
            <h4>   <p text align = "center"> <p><i><b> Criminal </b> is a popular term used for a person who has committed a crime or
                   has been legally convicted of a crime. <b> Criminal </b> also means
                    being connected with a crime. When certain acts or people are involved
                     in or related to a crime,
                   they are termed as criminal..
                   California's law is a good example. It prohibits using
                    obscenity and making threats against individuals and businesses. However, its prohibition against repeated calls only covers individual recipients, not businesses. It also does not apply to calls
                    made during the ordinary course and scope of business.</i>
                  </p></h4>
                 
               </div>
            </div><br><br>
           
           

           <h4> <p text align = "center">The last thing you want is more financial stress added to everything else you're 
               ... If you hire a lawyer who works at a large law firm,...then click on the link mentioned
              <a class = "link" href="services.php"><u> Click It </u></a></p></h4>
           
            <?php include 'footer.php';?>
           