
<?php include 'header.php';?>

<style>
   .link{
      color:blue;
   }
   .link:hover{
      color: rgb(141, 108, 52);
   }
</style>



<div width = "100%" height = "400px">
   <img src="assets/images/bg/family.png" alt="" width = "100%" height = "400px">
</div>
<div text align ="center" bold padding="10px"><br><br>
               <h1>Description</h1>
            </div>
<div class="row justify-content-center mt-5 g-4 container-fluid">
            <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInDown" data-wow-duration="1.5s" data-wow-delay="0.2s">
               <div class="casestudy-single" text align= "center">
                  <img src="assets/images/bg/family1.png" class="casestudy1" alt="image">
                
                  <div class="text">
                     
                  </div>
               </div>
            </div><br><br>
            <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInDown" data-wow-duration="1.5s" data-wow-delay="0.4s">
             
          <h4> <p text align = "center"><b><i> Family law,</b> also known as matrimonial law or the law of native relations,
           is an area of the law that deals with family affairs and domestic relations,
           such as adoption, divorce, child custody and support etcetera.
                  </p>
            <p> <b>family,</b> a group of persons united by the ties of marriage, blood, or adoption, 
                  constituting a single household and interacting with each other in their respective social positions,
                  usually those of spouses, <b>parents</b>, <b>children</b>, and siblings.</i>
                  </p></h4> 
                 
               </div>
            </div><br>
           
          

          <h4>  <p text align = "center">The last thing you want is more financial stress added to everything else you're 
               ... If you hire a lawyer who works at a large law firm,...then click on the link mentioned
                <a class = "link" href="services.php"><u> Click It </u></a></p></h4>
              <!-- <h2 text align = "center"> <a href="services.php">click it,s</a></h2>  -->
           
            <?php include 'footer.php';?>
           